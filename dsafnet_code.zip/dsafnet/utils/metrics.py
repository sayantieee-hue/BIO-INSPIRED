"""
Evaluation metrics for DSAF-Net.

Vessel segmentation: Dice, IoU, Pixel Accuracy, Sensitivity, Specificity.
CVD classification : Accuracy, Precision, Recall, F1, AUC (macro OvR).
"""

import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
)


# ---------------------------------------------------------------------------
# Segmentation metrics
# ---------------------------------------------------------------------------

def compute_segmentation_metrics(
    preds: torch.Tensor,
    targets: torch.Tensor,
    threshold: float = 0.5,
) -> dict:
    """
    Args:
        preds   : raw logits or probabilities (B, 1, H, W).
        targets : binary ground truth (B, 1, H, W) in {0, 1}.
    """
    probs = torch.sigmoid(preds) if preds.min() < 0 or preds.max() > 1 else preds
    binary_preds = (probs >= threshold).float()

    B = preds.size(0)
    p = binary_preds.view(B, -1).cpu().numpy()
    t = targets.view(B, -1).cpu().numpy()

    TP = (p * t).sum(axis=1)
    FP = (p * (1 - t)).sum(axis=1)
    FN = ((1 - p) * t).sum(axis=1)
    TN = ((1 - p) * (1 - t)).sum(axis=1)

    smooth = 1e-6
    dice = (2 * TP + smooth) / (2 * TP + FP + FN + smooth)
    iou = (TP + smooth) / (TP + FP + FN + smooth)
    acc = (TP + TN + smooth) / (TP + TN + FP + FN + smooth)
    sensitivity = (TP + smooth) / (TP + FN + smooth)
    specificity = (TN + smooth) / (TN + FP + smooth)

    return {
        "dice": float(dice.mean()),
        "iou": float(iou.mean()),
        "accuracy": float(acc.mean()),
        "sensitivity": float(sensitivity.mean()),
        "specificity": float(specificity.mean()),
    }


# ---------------------------------------------------------------------------
# CVD classification metrics
# ---------------------------------------------------------------------------

def compute_classification_metrics(
    logits: torch.Tensor,
    targets: torch.Tensor,
) -> dict:
    """
    Args:
        logits  : (B, num_classes) raw class logits.
        targets : (B,) integer class labels.
    """
    probs = F.softmax(logits, dim=1).cpu().numpy()
    preds = logits.argmax(dim=1).cpu().numpy()
    gt = targets.cpu().numpy()
    num_classes = logits.size(1)

    acc = accuracy_score(gt, preds)
    prec = precision_score(gt, preds, average="macro", zero_division=0)
    rec = recall_score(gt, preds, average="macro", zero_division=0)
    f1 = f1_score(gt, preds, average="macro", zero_division=0)

    try:
        auc = roc_auc_score(gt, probs, multi_class="ovr", average="macro")
    except ValueError:
        auc = float("nan")

    cm = confusion_matrix(gt, preds, labels=list(range(num_classes)))

    # Per-class metrics
    per_class = {}
    for cls in range(num_classes):
        tp = cm[cls, cls]
        fp = cm[:, cls].sum() - tp
        fn = cm[cls, :].sum() - tp
        tn = cm.sum() - tp - fp - fn
        s = 1e-6
        per_class[cls] = {
            "precision": float((tp + s) / (tp + fp + s)),
            "recall": float((tp + s) / (tp + fn + s)),
            "f1": float(2 * tp / (2 * tp + fp + fn + s)),
        }

    return {
        "accuracy": float(acc),
        "precision": float(prec),
        "recall": float(rec),
        "f1": float(f1),
        "auc": float(auc),
        "confusion_matrix": cm.tolist(),
        "per_class": per_class,
    }


# ---------------------------------------------------------------------------
# Aggregator for an entire epoch
# ---------------------------------------------------------------------------

class MetricAggregator:
    """Accumulate per-batch tensors and compute epoch-level metrics."""

    def __init__(self):
        self._seg_preds: list = []
        self._seg_targets: list = []
        self._cls_logits: list = []
        self._cls_targets: list = []

    def update(
        self,
        seg_logits: torch.Tensor,
        seg_targets: torch.Tensor,
        cvd_logits: torch.Tensor,
        cvd_targets: torch.Tensor,
    ):
        self._seg_preds.append(seg_logits.detach().cpu())
        self._seg_targets.append(seg_targets.detach().cpu())
        self._cls_logits.append(cvd_logits.detach().cpu())
        self._cls_targets.append(cvd_targets.detach().cpu())

    def compute(self) -> dict:
        seg_preds = torch.cat(self._seg_preds)
        seg_targets = torch.cat(self._seg_targets)
        cls_logits = torch.cat(self._cls_logits)
        cls_targets = torch.cat(self._cls_targets)

        seg_metrics = compute_segmentation_metrics(seg_preds, seg_targets)
        cls_metrics = compute_classification_metrics(cls_logits, cls_targets)

        return {"segmentation": seg_metrics, "classification": cls_metrics}

    def reset(self):
        self.__init__()
