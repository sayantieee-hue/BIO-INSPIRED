"""
DSAF-Net: Dual-Stream Attention Fusion Network
for Explainable Cardiovascular Risk Profiling via Fundus Imaging

Architecture:
  - Spatial stream: ResUNet encoder with CBAM attention
  - Spectral stream: 3-level DWT + CNN
  - Cross-stream attention fusion
  - Multi-task heads: vessel segmentation + CVD risk classification
  - Stream consistency loss

Reference:
  Deka et al., "Bio-Inspired Dual-Scale Attention Fusion Network for
  Explainable Cardiovascular Risk Profiling via Fundus Imaging"
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import pywt
import numpy as np


# ---------------------------------------------------------------------------
# CBAM: Convolutional Block Attention Module
# ---------------------------------------------------------------------------

class ChannelAttention(nn.Module):
    def __init__(self, in_channels: int, reduction: int = 16):
        super().__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)
        self.fc = nn.Sequential(
            nn.Conv2d(in_channels, in_channels // reduction, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(in_channels // reduction, in_channels, 1, bias=False),
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        return self.sigmoid(avg_out + max_out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        padding = kernel_size // 2
        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        concat = torch.cat([avg_out, max_out], dim=1)
        return self.sigmoid(self.conv(concat))


class CBAM(nn.Module):
    def __init__(self, in_channels: int, reduction: int = 16, kernel_size: int = 7):
        super().__init__()
        self.channel_att = ChannelAttention(in_channels, reduction)
        self.spatial_att = SpatialAttention(kernel_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x * self.channel_att(x)
        x = x * self.spatial_att(x)
        return x


# ---------------------------------------------------------------------------
# ResUNet building blocks
# ---------------------------------------------------------------------------

class ResBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, stride: int = 1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(out_channels, out_channels, 3, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.cbam = CBAM(out_channels)

        self.shortcut = nn.Sequential()
        if stride != 1 or in_channels != out_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_channels),
            )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = self.cbam(out)
        out = self.relu(out + self.shortcut(x))
        return out


class EncoderBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        self.block = ResBlock(in_channels, out_channels, stride=2)

    def forward(self, x: torch.Tensor):
        return self.block(x)


class DecoderBlock(nn.Module):
    def __init__(self, in_channels: int, skip_channels: int, out_channels: int):
        super().__init__()
        self.up = nn.ConvTranspose2d(in_channels, out_channels, 2, stride=2)
        self.block = ResBlock(out_channels + skip_channels, out_channels)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = self.up(x)
        # Handle size mismatch
        if x.shape != skip.shape:
            x = F.interpolate(x, size=skip.shape[2:], mode='bilinear', align_corners=True)
        x = torch.cat([x, skip], dim=1)
        return self.block(x)


# ---------------------------------------------------------------------------
# Spatial Stream (ResUNet + CBAM)
# ---------------------------------------------------------------------------

class SpatialStream(nn.Module):
    """ResUNet encoder that also returns skip connections for the decoder."""

    def __init__(self, in_channels: int = 3, base_channels: int = 64):
        super().__init__()
        c = base_channels
        self.stem = nn.Sequential(
            nn.Conv2d(in_channels, c, 7, padding=3, bias=False),
            nn.BatchNorm2d(c),
            nn.ReLU(inplace=True),
        )
        self.enc1 = EncoderBlock(c, c * 2)       # 64 -> 128
        self.enc2 = EncoderBlock(c * 2, c * 4)   # 128 -> 256
        self.enc3 = EncoderBlock(c * 4, c * 8)   # 256 -> 512
        self.bottleneck = ResBlock(c * 8, c * 8)

    def forward(self, x: torch.Tensor):
        s0 = self.stem(x)       # 1/1
        s1 = self.enc1(s0)      # 1/2
        s2 = self.enc2(s1)      # 1/4
        s3 = self.enc3(s2)      # 1/8
        f = self.bottleneck(s3) # 1/8
        return f, [s0, s1, s2, s3]


# ---------------------------------------------------------------------------
# Wavelet decomposition (DWT)
# ---------------------------------------------------------------------------

class DWTLayer(nn.Module):
    """3-level Daubechies-4 DWT decomposition returning stacked subbands."""

    def __init__(self, wavelet: str = "db4", level: int = 3):
        super().__init__()
        self.wavelet = wavelet
        self.level = level

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Returns concatenated subbands [ILL, ILH, IHL, IHH] stacked along
        channel dimension.  Each level halves spatial resolution.
        """
        B, C, H, W = x.shape
        device = x.device
        subbands = []

        x_np = x.detach().cpu().numpy()
        for b in range(B):
            channels = []
            for c in range(C):
                coeffs = pywt.wavedec2(x_np[b, c], self.wavelet, level=self.level)
                # coeffs[0] = LL (approx), coeffs[1..] = (LH, HL, HH) tuples
                ll = coeffs[0]
                lh, hl, hh = coeffs[1]
                # Resize all to same spatial size as LL
                target_h, target_w = ll.shape
                lh = np.array(
                    [pywt.resize(lh, (target_h, target_w))]
                    if lh.shape != (target_h, target_w) else [lh]
                )[0]
                hl = np.array(
                    [pywt.resize(hl, (target_h, target_w))]
                    if hl.shape != (target_h, target_w) else [hl]
                )[0]
                hh = np.array(
                    [pywt.resize(hh, (target_h, target_w))]
                    if hh.shape != (target_h, target_w) else [hh]
                )[0]
                # Stack 4 subbands for this channel
                channels.append(np.stack([ll, lh, hl, hh], axis=0))  # (4, h, w)
            subbands.append(np.concatenate(channels, axis=0))  # (4*C, h, w)

        subbands_np = np.stack(subbands, axis=0)  # (B, 4*C, h, w)
        return torch.from_numpy(subbands_np).float().to(device)


# ---------------------------------------------------------------------------
# Spectral Stream (DWT + CNN)
# ---------------------------------------------------------------------------

class SpectralStream(nn.Module):
    """Processes DWT subbands through a lightweight CNN."""

    def __init__(self, in_channels: int = 3, base_channels: int = 64):
        super().__init__()
        dwt_channels = in_channels * 4  # 4 subbands per input channel
        c = base_channels
        self.dwt = DWTLayer(wavelet="db4", level=3)
        self.conv_in = nn.Sequential(
            nn.Conv2d(dwt_channels, c, 3, padding=1, bias=False),
            nn.BatchNorm2d(c),
            nn.ReLU(inplace=True),
        )
        self.enc1 = ResBlock(c, c * 2, stride=1)
        self.enc2 = ResBlock(c * 2, c * 4, stride=1)
        self.enc3 = ResBlock(c * 4, c * 8, stride=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        subbands = self.dwt(x)                          # (B, 4C, H/2^L, W/2^L)
        f = self.conv_in(subbands)
        f = self.enc1(f)
        f = self.enc2(f)
        f = self.enc3(f)
        return f


# ---------------------------------------------------------------------------
# Cross-Stream Attention Fusion
# ---------------------------------------------------------------------------

class CrossStreamAttention(nn.Module):
    """
    Bidirectional cross-attention between spatial and spectral features.

    As→w = softmax( Qs Kw^T / sqrt(dk) ) Vw
    Aw→s = softmax( Qw Ks^T / sqrt(dk) ) Vs
    Ffused = concat(Fs + As→w, Fw + Aw→s)
    """

    def __init__(self, channels: int, num_heads: int = 8):
        super().__init__()
        self.channels = channels
        self.num_heads = num_heads
        self.head_dim = channels // num_heads
        assert channels % num_heads == 0, "channels must be divisible by num_heads"

        # Projections for spatial stream (query) and spectral stream (key/value)
        self.Wq_s = nn.Linear(channels, channels, bias=False)
        self.Wk_w = nn.Linear(channels, channels, bias=False)
        self.Wv_w = nn.Linear(channels, channels, bias=False)

        # Projections for spectral stream (query) and spatial stream (key/value)
        self.Wq_w = nn.Linear(channels, channels, bias=False)
        self.Wk_s = nn.Linear(channels, channels, bias=False)
        self.Wv_s = nn.Linear(channels, channels, bias=False)

        self.out_proj_s = nn.Linear(channels, channels, bias=False)
        self.out_proj_w = nn.Linear(channels, channels, bias=False)
        self.scale = self.head_dim ** -0.5

    def _reshape_to_heads(self, t: torch.Tensor, B: int, N: int) -> torch.Tensor:
        return t.view(B, N, self.num_heads, self.head_dim).transpose(1, 2)

    def _attention(self, Q, K, V) -> torch.Tensor:
        attn = (Q @ K.transpose(-2, -1)) * self.scale   # (B, heads, N, N)
        attn = F.softmax(attn, dim=-1)
        return attn @ V                                  # (B, heads, N, head_dim)

    def forward(self, Fs: torch.Tensor, Fw: torch.Tensor):
        B, C, Hs, Ws = Fs.shape
        _, _, Hw, Ww = Fw.shape

        # Align spatial sizes (interpolate spectral to match spatial)
        if (Hs, Ws) != (Hw, Ww):
            Fw_resized = F.interpolate(Fw, size=(Hs, Ws), mode='bilinear', align_corners=True)
        else:
            Fw_resized = Fw

        Ns = Hs * Ws
        # Flatten to sequence: (B, N, C)
        fs = Fs.flatten(2).transpose(1, 2)
        fw = Fw_resized.flatten(2).transpose(1, 2)

        # Spatial → Spectral attention
        Qs = self._reshape_to_heads(self.Wq_s(fs), B, Ns)
        Kw = self._reshape_to_heads(self.Wk_w(fw), B, Ns)
        Vw = self._reshape_to_heads(self.Wv_w(fw), B, Ns)
        As_w = self._attention(Qs, Kw, Vw)
        As_w = As_w.transpose(1, 2).contiguous().view(B, Ns, C)
        As_w = self.out_proj_s(As_w).transpose(1, 2).view(B, C, Hs, Ws)

        # Spectral → Spatial attention
        Qw = self._reshape_to_heads(self.Wq_w(fw), B, Ns)
        Ks = self._reshape_to_heads(self.Wk_s(fs), B, Ns)
        Vs = self._reshape_to_heads(self.Wv_s(fs), B, Ns)
        Aw_s = self._attention(Qw, Ks, Vs)
        Aw_s = Aw_s.transpose(1, 2).contiguous().view(B, Ns, C)
        Aw_s = self.out_proj_w(Aw_s).transpose(1, 2).view(B, C, Hs, Ws)

        Fs_enhanced = Fs + As_w
        Fw_enhanced = Fw_resized + Aw_s

        Ffused = torch.cat([Fs_enhanced, Fw_enhanced], dim=1)  # (B, 2C, H, W)
        return Ffused, Fs_enhanced, Fw_enhanced


# ---------------------------------------------------------------------------
# Segmentation Decoder
# ---------------------------------------------------------------------------

class SegmentationDecoder(nn.Module):
    def __init__(self, fused_channels: int, skip_channels_list: list, base_channels: int = 64):
        super().__init__()
        c = base_channels
        # fused_channels = 2 * 8c = 16c
        self.dec3 = DecoderBlock(fused_channels, skip_channels_list[3], c * 4)
        self.dec2 = DecoderBlock(c * 4, skip_channels_list[2], c * 2)
        self.dec1 = DecoderBlock(c * 2, skip_channels_list[1], c)
        self.dec0 = DecoderBlock(c, skip_channels_list[0], c)
        self.head = nn.Conv2d(c, 1, 1)

    def forward(self, fused: torch.Tensor, skips: list) -> torch.Tensor:
        s0, s1, s2, s3 = skips
        x = self.dec3(fused, s3)
        x = self.dec2(x, s2)
        x = self.dec1(x, s1)
        x = self.dec0(x, s0)
        return self.head(x)


# ---------------------------------------------------------------------------
# CVD Risk Classifier
# ---------------------------------------------------------------------------

class CVDClassifier(nn.Module):
    def __init__(self, fused_channels: int, num_classes: int = 3):
        super().__init__()
        self.global_pool = nn.AdaptiveAvgPool2d(1)
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(fused_channels, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(256, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.global_pool(x)
        return self.classifier(x)


# ---------------------------------------------------------------------------
# DSAF-Net — Full Model
# ---------------------------------------------------------------------------

class DSAFNet(nn.Module):
    """
    Dual-Stream Attention Fusion Network (DSAF-Net).

    Args:
        in_channels   : number of input image channels (default: 3, RGB).
        base_channels : base feature dimension (default: 64).
        num_classes   : number of CVD risk classes (default: 3: Low/Medium/High).
        num_heads     : number of cross-attention heads (default: 8).
    """

    def __init__(
        self,
        in_channels: int = 3,
        base_channels: int = 64,
        num_classes: int = 3,
        num_heads: int = 8,
    ):
        super().__init__()
        c = base_channels
        bottleneck_channels = c * 8  # 512

        # Streams
        self.spatial_stream = SpatialStream(in_channels, base_channels)
        self.spectral_stream = SpectralStream(in_channels, base_channels)

        # Cross-attention fusion
        self.cross_attention = CrossStreamAttention(bottleneck_channels, num_heads)
        fused_channels = bottleneck_channels * 2  # concat → 1024

        # Segmentation decoder (skip channel sizes from spatial encoder)
        skip_channels = [c, c * 2, c * 4, c * 8]
        self.seg_decoder = SegmentationDecoder(fused_channels, skip_channels, base_channels)

        # CVD classifier
        self.cvd_classifier = CVDClassifier(fused_channels, num_classes)

    def forward(self, x: torch.Tensor):
        """
        Args:
            x: Input fundus image tensor of shape (B, 3, H, W).

        Returns:
            seg_logits : Vessel segmentation logits  (B, 1, H, W).
            cvd_logits : CVD risk classification logits (B, num_classes).
            Fs_enhanced: Attention-enriched spatial features (for consistency loss).
            Fw_enhanced: Attention-enriched spectral features (for consistency loss).
        """
        # --- Stream 1: Spatial ---
        Fs, skips = self.spatial_stream(x)

        # --- Stream 2: Spectral ---
        Fw = self.spectral_stream(x)

        # --- Cross-Stream Attention Fusion ---
        Ffused, Fs_enh, Fw_enh = self.cross_attention(Fs, Fw)

        # --- Multi-Task Prediction ---
        seg_logits = self.seg_decoder(Ffused, skips)
        # Upsample to original resolution
        seg_logits = F.interpolate(seg_logits, size=x.shape[2:], mode='bilinear', align_corners=True)

        cvd_logits = self.cvd_classifier(Ffused)

        return seg_logits, cvd_logits, Fs_enh, Fw_enh
