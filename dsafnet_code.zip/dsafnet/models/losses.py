"""
Loss functions for DSAF-Net multi-task learning.

Total loss:  ℒ_total = λ1 ℒ_seg + λ2 ℒ_cls + λ3 ℒ_cons
  - ℒ_seg  = 0.6 · FocalLoss + 0.4 · DiceLoss
  - ℒ_cls  = CrossEntropyLoss
  - ℒ_cons = max(0, cosine_similarity(Fs, Fw) − τ)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Focal Loss
# ---------------------------------------------------------------------------

class FocalLoss(nn.Module):
    def __init__(self, alpha: float = 0.25, gamma: float = 2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        """
        Args:
            logits  : (B, 1, H, W) raw output (before sigmoid).
            targets : (B, 1, H, W) binary ground truth in {0, 1}.
        """
        probs = torch.sigmoid(logits)
        bce = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
        pt = probs * targets + (1 - probs) * (1 - targets)
        focal_weight = self.alpha * (1 - pt) ** self.gamma
        return (focal_weight * bce).mean()


# ---------------------------------------------------------------------------
# Dice Loss
# ---------------------------------------------------------------------------

class DiceLoss(nn.Module):
    def __init__(self, smooth: float = 1.0):
        super().__init__()
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        probs = torch.sigmoid(logits)
        B = probs.size(0)
        probs_flat = probs.view(B, -1)
        targets_flat = targets.view(B, -1)
        intersection = (probs_flat * targets_flat).sum(dim=1)
        dice = (2 * intersection + self.smooth) / (
            probs_flat.sum(dim=1) + targets_flat.sum(dim=1) + self.smooth
        )
        return 1 - dice.mean()


# ---------------------------------------------------------------------------
# Segmentation Loss  (0.6 Focal + 0.4 Dice)
# ---------------------------------------------------------------------------

class SegmentationLoss(nn.Module):
    def __init__(self, focal_alpha: float = 0.25, focal_gamma: float = 2.0, smooth: float = 1.0):
        super().__init__()
        self.focal = FocalLoss(focal_alpha, focal_gamma)
        self.dice = DiceLoss(smooth)

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        return 0.6 * self.focal(logits, targets) + 0.4 * self.dice(logits, targets)


# ---------------------------------------------------------------------------
# Stream Consistency Loss
# ---------------------------------------------------------------------------

class StreamConsistencyLoss(nn.Module):
    """
    Penalises redundancy between spatial and spectral streams:

        ℒ_cons = max(0, cos(Fs, Fw) − τ)

    where τ = 0.3 (paper default).
    """

    def __init__(self, tau: float = 0.3):
        super().__init__()
        self.tau = tau

    def forward(self, Fs: torch.Tensor, Fw: torch.Tensor) -> torch.Tensor:
        Fs_flat = Fs.flatten(1)
        Fw_flat = Fw.flatten(1)
        cos_sim = F.cosine_similarity(Fs_flat, Fw_flat, dim=1).mean()
        return torch.clamp(cos_sim - self.tau, min=0.0)


# ---------------------------------------------------------------------------
# Combined Multi-Task Loss
# ---------------------------------------------------------------------------

class DSAFNetLoss(nn.Module):
    """
    Total loss with configurable weights (paper defaults: λ1=0.4, λ2=0.4, λ3=0.2).
    """

    def __init__(
        self,
        lambda_seg: float = 0.4,
        lambda_cls: float = 0.4,
        lambda_cons: float = 0.2,
        tau: float = 0.3,
    ):
        super().__init__()
        self.lambda_seg = lambda_seg
        self.lambda_cls = lambda_cls
        self.lambda_cons = lambda_cons

        self.seg_loss = SegmentationLoss()
        self.cls_loss = nn.CrossEntropyLoss()
        self.cons_loss = StreamConsistencyLoss(tau)

    def forward(
        self,
        seg_logits: torch.Tensor,
        seg_targets: torch.Tensor,
        cvd_logits: torch.Tensor,
        cvd_targets: torch.Tensor,
        Fs: torch.Tensor,
        Fw: torch.Tensor,
    ) -> dict:
        L_seg = self.seg_loss(seg_logits, seg_targets.float())
        L_cls = self.cls_loss(cvd_logits, cvd_targets)
        L_cons = self.cons_loss(Fs, Fw)
        L_total = self.lambda_seg * L_seg + self.lambda_cls * L_cls + self.lambda_cons * L_cons

        return {
            "total": L_total,
            "seg": L_seg,
            "cls": L_cls,
            "cons": L_cons,
        }
