"""
Dataset utilities for DSAF-Net.

Supports DRIVE, STARE, and CHASEDB1 retinal fundus datasets.
Applies CLAHE preprocessing and proxy CVD risk labelling
(threshold-based, as described in the paper).
"""

import os
import random
import numpy as np
import cv2
from pathlib import Path
from typing import Tuple, Optional, List

import torch
from torch.utils.data import Dataset
import torchvision.transforms.functional as TF
from PIL import Image


# ---------------------------------------------------------------------------
# CLAHE Preprocessing
# ---------------------------------------------------------------------------

def apply_clahe(img_rgb: np.ndarray, clip_limit: float = 2.0, tile_grid: tuple = (8, 8)) -> np.ndarray:
    """Apply CLAHE to the green channel (most informative for retinal vessels)."""
    lab = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid)
    l_clahe = clahe.apply(l_channel)
    lab_clahe = cv2.merge([l_clahe, a_channel, b_channel])
    return cv2.cvtColor(lab_clahe, cv2.COLOR_LAB2RGB)


# ---------------------------------------------------------------------------
# Proxy CVD Risk Labelling
# ---------------------------------------------------------------------------

def compute_vascular_biomarkers(mask: np.ndarray) -> dict:
    """
    Extract quantitative vascular features from a binary vessel mask.
    Used for proxy CVD risk labelling (Low/Medium/High).
    """
    binary = (mask > 128).astype(np.uint8)

    # 1. Vessel density (fraction of vessel pixels)
    vessel_density = binary.mean()

    # 2. Vessel caliber estimate (average skeleton width via distance transform)
    skeleton_dist = cv2.distanceTransform(binary, cv2.DIST_L2, 5)
    avg_caliber = float(skeleton_dist[skeleton_dist > 0].mean()) if binary.any() else 0.0

    # 3. Tortuosity proxy: ratio of vessel pixels to convex hull area
    contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    hull_area = sum(cv2.contourArea(cv2.convexHull(c)) for c in contours) + 1e-6
    tortuosity = float(binary.sum()) / hull_area

    # 4. Branching point density (pixels with 3+ vessel neighbours)
    kernel = np.ones((3, 3), np.uint8)
    neighbor_count = cv2.filter2D(binary.astype(float), -1, kernel) - binary
    branch_pixels = ((neighbor_count >= 3) & (binary == 1)).sum()
    branching_density = branch_pixels / (binary.sum() + 1e-6)

    return {
        "vessel_density": vessel_density,
        "avg_caliber": avg_caliber,
        "tortuosity": tortuosity,
        "branching_density": branching_density,
    }


def assign_cvd_risk_label(biomarkers: dict, population_stats: Optional[dict] = None) -> int:
    """
    Threshold-based proxy labelling:
      - Images within 1 SD of population mean → Low Risk (0)
      - 1–2 SD → Medium Risk (1)
      - >2 SD → High Risk (2)

    If population_stats is None, a simple heuristic is used.
    Returns int in {0, 1, 2}.
    """
    if population_stats is None:
        # Heuristic fallback
        density = biomarkers["vessel_density"]
        if density < 0.06:
            return 2  # Low density → high risk
        elif density < 0.10:
            return 1
        else:
            return 0

    # Compute z-score across all biomarkers
    z_scores = []
    for key, val in biomarkers.items():
        if key in population_stats:
            mean, std = population_stats[key]
            z_scores.append(abs(val - mean) / (std + 1e-8))
    avg_z = float(np.mean(z_scores)) if z_scores else 0.0

    if avg_z <= 1.0:
        return 0
    elif avg_z <= 2.0:
        return 1
    else:
        return 2


# ---------------------------------------------------------------------------
# Data Augmentation
# ---------------------------------------------------------------------------

class RetinalAugmentation:
    """Random augmentations applied jointly to image and mask."""

    def __init__(
        self,
        flip_prob: float = 0.5,
        rotation_range: float = 15.0,
        brightness_range: Tuple[float, float] = (0.8, 1.2),
    ):
        self.flip_prob = flip_prob
        self.rotation_range = rotation_range
        self.brightness_range = brightness_range

    def __call__(self, image: Image.Image, mask: Image.Image):
        # Horizontal flip
        if random.random() < self.flip_prob:
            image = TF.hflip(image)
            mask = TF.hflip(mask)

        # Vertical flip
        if random.random() < self.flip_prob:
            image = TF.vflip(image)
            mask = TF.vflip(mask)

        # Random rotation
        angle = random.uniform(-self.rotation_range, self.rotation_range)
        image = TF.rotate(image, angle)
        mask = TF.rotate(mask, angle)

        # Brightness jitter (image only)
        factor = random.uniform(*self.brightness_range)
        image = TF.adjust_brightness(image, factor)

        return image, mask


# ---------------------------------------------------------------------------
# Dataset
# ---------------------------------------------------------------------------

class FundusDataset(Dataset):
    """
    Generic retinal fundus dataset.

    Expected directory layout:
        root/
          images/   *.png or *.tif
          masks/    *.png  (binary vessel ground-truth)

    CVD risk labels are either:
      (a) loaded from a pre-computed CSV (label_csv), or
      (b) computed on-the-fly from vascular biomarkers.
    """

    def __init__(
        self,
        root: str,
        image_size: Tuple[int, int] = (512, 512),
        augment: bool = True,
        label_csv: Optional[str] = None,
        population_stats: Optional[dict] = None,
    ):
        self.root = Path(root)
        self.image_size = image_size
        self.augment = augment
        self.population_stats = population_stats
        self.transform = RetinalAugmentation() if augment else None

        img_dir = self.root / "images"
        mask_dir = self.root / "masks"

        self.image_paths: List[Path] = sorted(img_dir.glob("*"))
        self.mask_paths: List[Path] = sorted(mask_dir.glob("*"))
        assert len(self.image_paths) == len(self.mask_paths), (
            f"Mismatch: {len(self.image_paths)} images vs {len(self.mask_paths)} masks"
        )

        # Load or compute CVD labels
        if label_csv and os.path.exists(label_csv):
            import csv
            label_map = {}
            with open(label_csv, newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    label_map[row["filename"]] = int(row["label"])
            self.cvd_labels = [label_map.get(p.name, 0) for p in self.image_paths]
        else:
            self.cvd_labels = None  # Will be computed per-sample

    def __len__(self) -> int:
        return len(self.image_paths)

    def __getitem__(self, idx: int) -> dict:
        # Load image
        img_np = cv2.imread(str(self.image_paths[idx]))
        img_np = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
        img_np = apply_clahe(img_np)

        # Load mask
        mask_np = cv2.imread(str(self.mask_paths[idx]), cv2.IMREAD_GRAYSCALE)

        # CVD label
        if self.cvd_labels is not None:
            cvd_label = self.cvd_labels[idx]
        else:
            biomarkers = compute_vascular_biomarkers(mask_np)
            cvd_label = assign_cvd_risk_label(biomarkers, self.population_stats)

        # Resize
        img_pil = Image.fromarray(img_np).resize(self.image_size, Image.BILINEAR)
        mask_pil = Image.fromarray(mask_np).resize(self.image_size, Image.NEAREST)

        # Augment
        if self.transform:
            img_pil, mask_pil = self.transform(img_pil, mask_pil)

        # To tensor
        image = TF.to_tensor(img_pil)                             # (3, H, W) float [0,1]
        mask = torch.from_numpy(np.array(mask_pil)).float() / 255  # (H, W) float [0,1]
        mask = mask.unsqueeze(0)                                   # (1, H, W)

        return {
            "image": image,
            "mask": mask,
            "cvd_label": torch.tensor(cvd_label, dtype=torch.long),
            "filename": self.image_paths[idx].name,
        }
